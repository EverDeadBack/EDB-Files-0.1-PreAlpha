import random

import arcade

WIDTH = 1024
HEIGHT = 768
TITLE = "EverDeadBack"

GRAVITU = 3


# Класс букв
class Letters(arcade.Sprite):
    def __init__(self, x, y, l):
        super().__init__()
        self.textures = []
        self.center_y = y
        self.center_x = x
        self.scale = 0.3
        for i in range(25):
            self.textures.append(arcade.load_texture(f"Sprite/letters/letter{i}.png"))
        self.texture = self.textures[l]


# Класс цифр
class Nummers(arcade.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.textures = []
        self.center_y = y
        self.center_x = x
        self.scale = 0.3
        for i in range(10):
            self.textures.append(arcade.load_texture(f"Sprite/Nummers/{i}.png"))


# Визуализатор сердец(спрайта)
class Heards(arcade.Sprite):
    def __init__(self):
        super().__init__()
        self.healt = []
        self.healt.append(arcade.load_texture("Sprite/GUI/healt.png"))
        self.healt.append(arcade.load_texture("Sprite/GUI/healtoff.png"))
        self.center_x = 55
        self.center_y = HEIGHT - 50
        self.scale = 1.3


# Визуализатор кнопки(спрайта)
class Buttons_visual(arcade.Sprite):
    def __init__(self):
        super().__init__()
        self.butt = []
        self.butt.append(arcade.load_texture("Sprite/GUI/butt2.png"))
        self.butt.append(arcade.load_texture("Sprite/GUI/butt1.png"))
        self.center_x = 230
        self.center_y = HEIGHT - 50
        self.scale = 1.1


# Визуализатор оружия
class Gun(arcade.Sprite):
    def __init__(self):
        super().__init__()
        self.textures_1 = []
        self.textures_1.append(arcade.load_texture("Sprite/Weapons/gun/gun0.png"))
        self.textures_1.append(arcade.load_texture("Sprite/Weapons/gun/gun0.png", flipped_horizontally=True))
        self.textures_2 = []
        self.textures_2.append(arcade.load_texture("Sprite/Weapons/gun/gun1.png"))
        self.textures_2.append(arcade.load_texture("Sprite/Weapons/gun/gun1.png", flipped_horizontally=True))
        self.textures_3 = []
        self.textures_3.append(arcade.load_texture("Sprite/Weapons/gun/gun2.png"))
        self.textures_3.append(arcade.load_texture("Sprite/Weapons/gun/gun2.png", flipped_horizontally=True))
        self.textures_4 = []
        self.textures_4.append(arcade.load_texture("Sprite/Weapons/gun/gun3.png"))
        self.textures_4.append(arcade.load_texture("Sprite/Weapons/gun/gun3.png", flipped_horizontally=True))
        self.textures_5 = []
        self.textures_5.append(arcade.load_texture("Sprite/Weapons/gun/gun4.png"))
        self.textures_5.append(arcade.load_texture("Sprite/Weapons/gun/gun4.png", flipped_horizontally=True))
        self.textures_6 = []
        self.textures_6.append(arcade.load_texture("Sprite/Weapons/gun/gun5.png"))
        self.textures_6.append(arcade.load_texture("Sprite/Weapons/gun/gun5.png", flipped_horizontally=True))
        self.textures_7 = []
        self.textures_7.append(arcade.load_texture("Sprite/Weapons/gun/gun6.png"))
        self.textures_7.append(arcade.load_texture("Sprite/Weapons/gun/gun6.png", flipped_horizontally=True))
        self.textures_8 = []
        self.textures_8.append(arcade.load_texture("Sprite/Weapons/gun/gun7.png"))
        self.textures_8.append(arcade.load_texture("Sprite/Weapons/gun/gun7.png", flipped_horizontally=True))
        self.center_y = 0
        self.center_x = 0
        self.texture = self.textures_1[0]
        self.scale = 1.1
        self.cartridges = 60
        self.gun_damage = 3
        self.gun_visual_vid = 1
        self.rotate_flip = 0
        self.add_select_guns = True
        self.tick_fire = 0
        self.add_fire = 0
        # simple fire takeover vampirism
        self.type_effect = "simple"
        self.random_chance = 0
        self.gun_chance = 0
        self.range = 0

    def update(self):
        if self.add_fire < self.tick_fire:
            self.add_fire += 1
        if self.gun_visual_vid == 1:
            self.texture = self.textures_1[self.rotate_flip]
        if self.gun_visual_vid == 2:
            self.texture = self.textures_2[self.rotate_flip]
        if self.gun_visual_vid == 3:
            self.texture = self.textures_3[self.rotate_flip]
        if self.gun_visual_vid == 4:
            self.texture = self.textures_4[self.rotate_flip]
        if self.gun_visual_vid == 5:
            self.texture = self.textures_5[self.rotate_flip]
        if self.gun_visual_vid == 6:
            self.texture = self.textures_6[self.rotate_flip]
        if self.gun_visual_vid == 7:
            self.texture = self.textures_7[self.rotate_flip]
        if self.gun_visual_vid == 8:
            self.texture = self.textures_8[self.rotate_flip]

        if self.add_select_guns == True:
            self.add_select_guns = False
            if self.gun_visual_vid == 1:
                self.tick_fire = 10
                self.add_fire = 0
                self.cartridges = 60
                self.gun_damage = 3
                self.type_effect = "simple"
                self.gun_chance = 10
                self.range = 500
            if self.gun_visual_vid == 2:
                self.tick_fire = 15
                self.add_fire = 0
                self.cartridges = 5
                self.gun_damage = 10
                self.type_effect = "simple"
                self.gun_chance = 5
                self.range = 300
            if self.gun_visual_vid == 3:
                self.tick_fire = 5
                self.add_fire = 0
                self.cartridges = 80
                self.gun_damage = 2
                self.type_effect = "simple"
                self.gun_chance = 3
                self.range = 900
            if self.gun_visual_vid == 4:
                self.tick_fire = 7
                self.add_fire = 0
                self.cartridges = 10
                self.gun_damage = 6
                self.type_effect = "vampirism"
                self.gun_chance = 150
                self.range = 600
            if self.gun_visual_vid == 5:
                self.tick_fire = 15
                self.add_fire = 0
                self.cartridges = 30
                self.gun_damage = 7
                self.type_effect = "fire"
                self.gun_chance = 8
                self.range = 650
            if self.gun_visual_vid == 6:
                self.tick_fire = 25
                self.add_fire = 0
                self.cartridges = 2
                self.gun_damage = 15
                self.type_effect = "takeover"
                self.gun_chance = 20
                self.range = 1000
            if self.gun_visual_vid == 7:
                self.tick_fire = 5
                self.add_fire = 0
                self.cartridges = 66
                self.gun_damage = 1
                self.type_effect = "takeover"
                self.gun_chance = 2
                self.range = 400
            if self.gun_visual_vid == 8:
                self.tick_fire = 4
                self.add_fire = 0
                self.cartridges = 45
                self.gun_damage = 4
                self.type_effect = "vampirism"
                self.gun_chance = 666
                self.range = 700


# Хитбокс

class Visual_player(arcade.Sprite):
    def __init__(self):
        super().__init__()
        self.textures_r = []
        for i in range(6):
            self.textures_r.append(arcade.load_texture(f"Sprite/Player/pl{i}.png", flipped_horizontally=True))
        self.textures_rs = []
        for i in range(6):
            self.textures_rs.append(arcade.load_texture(f"Sprite/Player/pls{i}.png", flipped_horizontally=True))
        self.textures_l = []
        for i in range(6):
            self.textures_l.append(arcade.load_texture(f"Sprite/Player/pl{i}.png"))
        self.textures_ls = []
        for i in range(6):
            self.textures_ls.append(arcade.load_texture(f"Sprite/Player/pls{i}.png"))
        self.textures_l_stand = []
        for i in range(6):
            self.textures_l_stand.append(arcade.load_texture(f"Sprite/Player/plsta{i}.png"))

        self.textures_r_stand = []
        for i in range(6):
            self.textures_r_stand.append(arcade.load_texture(f"Sprite/Player/plsta{i}.png", flipped_horizontally=True))

        self.textures_l_stand_sit = []
        for i in range(6):
            self.textures_l_stand_sit.append(arcade.load_texture(f"Sprite/Player/plstasit{i}.png"))

        self.textures_r_stand_sit = []
        for i in range(6):
            self.textures_r_stand_sit.append(
                arcade.load_texture(f"Sprite/Player/plstasit{i}.png", flipped_horizontally=True))

        self.anim = True
        self.t_index = 0
        self.texture = self.textures_l[0]
        self.center_x = 0
        self.center_y = 0
        self.scale = 1.1
        self.s_sit = False
        self.tick = 0

    def update(self):
        self.tick += 0.6
        if self.tick >= 1:
            self.tick = 0
            self.t_index += 0.5

        if self.t_index == 6:
            self.t_index = 0


# Визуализотор персонажа(игрока)
class Character(arcade.Sprite):
    def __init__(self):
        super().__init__("Sprite/Player/hitbox.png")
        self.scale = 1
        self.center_x = 30
        self.center_y = 200
        self.speed_x = 0
        self.speed_y = 0
        self.on_jump = False
        self.healt = 5
        self.zreset = 100
        self.speed_player = 15

    def update(self):
        if self.on_jump == True:
            self.center_y += 50
        if self.zreset != 100:
            self.zreset += 0.5
        if self.center_x <= 0:
            self.center_x = 1


# Враги
class Emety(arcade.Sprite):
    def __init__(self, x, y, h):
        super().__init__()
        self.textures_rn = []
        self.textures_ln = []
        for i in range(0, 2):
            self.textures_rn.append(arcade.load_texture(f"Sprite/Enemy/BlebNormal/bleb{i}.png"))
        self.textures_rn.append(arcade.load_texture("Sprite/Enemy/BlebNormal/bleb2.png"))
        for i in range(0, 2):
            self.textures_ln.append(
                arcade.load_texture(f"Sprite/Enemy/BlebNormal/bleb{i}.png", flipped_horizontally=True))
        self.textures_ln.append(arcade.load_texture("Sprite/Enemy/BlebNormal/bleb2.png", flipped_horizontally=True))

        self.textures_rs = []
        self.textures_ls = []
        for i in range(0, 2):
            self.textures_rs.append(arcade.load_texture(f"Sprite/Enemy/BlebSpeed/blebRed{i}.png"))
        self.textures_rs.append(arcade.load_texture("Sprite/Enemy/BlebSpeed/blebRed2.png"))
        for i in range(0, 2):
            self.textures_ls.append(
                arcade.load_texture(f"Sprite/Enemy/BlebSpeed/blebRed{i}.png", flipped_horizontally=True))
        self.textures_ls.append(arcade.load_texture("Sprite/Enemy/BlebSpeed/blebRed2.png", flipped_horizontally=True))

        self.textures_rh = []
        self.textures_lh = []
        for i in range(0, 2):
            self.textures_rh.append(arcade.load_texture(f"Sprite/Enemy/BlebHP/bleb cube{i}.png"))
        self.textures_rh.append(arcade.load_texture("Sprite/Enemy/BlebHP/bleb cube2.png"))
        for i in range(0, 2):
            self.textures_lh.append(
                arcade.load_texture(f"Sprite/Enemy/BlebHP/bleb cube{i}.png", flipped_horizontally=True))
        self.textures_lh.append(arcade.load_texture("Sprite/Enemy/BlebHP/bleb cube2.png", flipped_horizontally=True))

        self.textures_r_sbeve = []
        self.textures_l_sbeve = []
        for i in range(0, 2):
            self.textures_r_sbeve.append(arcade.load_texture(f"Sprite/Enemy/Sbeve/SbeveNormal/sbeve{i}.png"))
        self.textures_r_sbeve.append(arcade.load_texture("Sprite/Enemy/Sbeve/SbeveNormal/sbeve2.png"))
        for i in range(0, 2):
            self.textures_l_sbeve.append(
                arcade.load_texture(f"Sprite/Enemy/Sbeve/SbeveNormal/sbeve{i}.png", flipped_horizontally=True))
        self.textures_l_sbeve.append(
            arcade.load_texture("Sprite/Enemy/Sbeve/SbeveNormal/sbeve2.png", flipped_horizontally=True))

        self.textures_r_sbeve_angry = []
        self.textures_l_sbeve_angry = []
        for i in range(0, 2):
            self.textures_r_sbeve_angry.append(arcade.load_texture(f"Sprite/Enemy/Sbeve/SbeveAngry/sbeve_angry{i}.png"))
        self.textures_r_sbeve_angry.append(arcade.load_texture("Sprite/Enemy/Sbeve/SbeveAngry/sbeve_angry2.png"))
        for i in range(0, 2):
            self.textures_l_sbeve_angry.append(
                arcade.load_texture(f"Sprite/Enemy/Sbeve/SbeveAngry/sbeve_angry{i}.png", flipped_horizontally=True))
        self.textures_l_sbeve_angry.append(
            arcade.load_texture("Sprite/Enemy/Sbeve/SbeveAngry/sbeve_angry2.png", flipped_horizontally=True))

        self.texture = self.textures_rn[0]
        self.center_x = x
        self.center_y = y
        self.healt = h
        self.speed = 2
        self.scale = 0.55
        self.flip = False
        self.run = False
        self.bleba_vid = 1
        self.true_vid = False
        self.index_a = 0
        self.col_enemy = False

    def update(self):
        self.index_a += 0.2
        if self.index_a > 3:
            self.index_a = 0
        if self.healt > 0:
            if self.flip == False:
                if self.bleba_vid == 1:
                    self.texture = self.textures_rn[int(self.index_a)]
                elif self.bleba_vid == 2:
                    self.texture = self.textures_rs[int(self.index_a)]
                elif self.bleba_vid == 3:
                    self.texture = self.textures_rh[int(self.index_a)]
                elif self.bleba_vid >= 4:
                    if self.healt >= 80:
                        self.texture = self.textures_r_sbeve[int(self.index_a)]
                    elif self.healt < 80:
                        self.texture = self.textures_r_sbeve_angry[int(self.index_a)]
                self.center_x += self.speed
            else:
                if self.bleba_vid == 1:
                    self.texture = self.textures_ln[int(self.index_a)]
                elif self.bleba_vid == 2:
                    self.texture = self.textures_ls[int(self.index_a)]
                elif self.bleba_vid == 3:
                    self.texture = self.textures_lh[int(self.index_a)]
                elif self.bleba_vid >= 4:
                    if self.healt >= 80:
                        self.texture = self.textures_l_sbeve[int(self.index_a)]
                    elif self.healt < 80:
                        self.texture = self.textures_l_sbeve_angry[int(self.index_a)]
                self.center_x -= self.speed

        if self.true_vid == True:
            self.col_enemy = True
            self.center_y = 100
            self.bleba_vid = random.randint(1, 4)
            #Виды мобов(врагов)
            if self.bleba_vid == 1:
                self.speed = 2
                self.healt = 60
            if self.bleba_vid == 2:
                self.speed = 6
                self.healt = 30
            if self.bleba_vid == 3:
                self.speed = 1
                self.healt = 100
            if self.bleba_vid >= 4:
                self.speed = 1
                self.healt = 200
            self.center_x = random.uniform(500, WIDTH)
            self.center_y = random.uniform(200, 600)
        if self.col_enemy == False:
            self.center_y = + 4000
        if self.bleba_vid >= 4:
            if self.healt >= 80:
                self.speed = 1
            elif self.healt < 80:
                self.speed = 6

        self.true_vid = False


# Визуализатор патронов
class Buttimage(arcade.Sprite):
    def __init__(self):
        super().__init__()
        self.center_x = 0
        self.center_y = 0
        self.scale = 0.9
        self.image1 = []
        self.image2 = []
        self.image3 = []
        self.image4 = []
        self.image1.append(arcade.load_texture("Sprite/Weapons/cartridges/particle_1.png"))
        self.image1.append(arcade.load_texture("Sprite/Weapons/cartridges/particle_1.png", flipped_horizontally=True))
        self.image2.append(arcade.load_texture("Sprite/Weapons/cartridges/particle_2.png"))
        self.image2.append(arcade.load_texture("Sprite/Weapons/cartridges/particle_2.png", flipped_horizontally=True))
        self.image3.append(arcade.load_texture("Sprite/Weapons/cartridges/particle_3.png"))
        self.image3.append(arcade.load_texture("Sprite/Weapons/cartridges/particle_3.png", flipped_horizontally=True))
        self.image4.append(arcade.load_texture("Sprite/Weapons/cartridges/particle_4.png"))
        self.image4.append(arcade.load_texture("Sprite/Weapons/cartridges/particle_4.png", flipped_horizontally=True))
        self.texture = self.image1[0]


# Хитбокс и стены их
class Walls(arcade.Sprite):
    def __init__(self, x, y, s, n):
        super().__init__()
        self.center_x = x
        self.center_y = y
        self.textures = []
        self.scale = s
        self.textures.append(arcade.load_texture("Sprite/Walls/walls.png"))
        self.textures.append(arcade.load_texture("Sprite/Walls/waal.png"))
        self.texture = self.textures[n]


# Основной код игры(гемплея)
class Game(arcade.View):
    def __init__(self):
        super().__init__()
        self.visual = Visual_player()
        self.gun = False
        self.guns = Gun()
        self.hero = Character()
        self.herds = Heards()
        self.mx = 0
        self.visual_button = Buttons_visual()
        self.num = Nummers(100, HEIGHT - 50)
        self.num2 = Nummers(265, HEIGHT - 50)
        self.num3 = Nummers(300, HEIGHT - 50)
        self.emetys = arcade.SpriteList()
        self.emety1 = Emety(random.uniform(300, 1000), 115, 0)
        self.emetys.append(self.emety1)
        self.walls = arcade.SpriteList()
        self.wall = Walls(WIDTH // 2, 30, 2.5, 0)
        self.walls.append(self.wall)
        self.wall1 = Walls(250, 300, 1, 1)
        self.walls.append(self.wall1)
        self.wall2 = Walls(770, 300, 1, 1)
        self.walls.append(self.wall2)
        self.physics_engine = arcade.PhysicsEnginePlatformer(
            self.hero, gravity_constant=GRAVITU, walls=self.walls)
        self.physics_engine1 = arcade.PhysicsEnginePlatformer(
            self.emety1, gravity_constant=GRAVITU, walls=self.walls)
        self.junp_sound = arcade.load_sound("Sound/jump.wav")
        self.hit_sound = arcade.load_sound("Sound/hitHurt.wav")
        self.gun_sound_1 = arcade.load_sound("Sound/explosion (1).wav")
        self.gun_sound_2 = arcade.load_sound("Sound/explosion (2).wav")
        self.gun_sound_3 = arcade.load_sound("Sound/explosion (3).wav")
        self.gun_sound_4 = arcade.load_sound("Sound/explosion (4).wav")
        self.gun_sound_5 = arcade.load_sound("Sound/explosion (5).wav")
        self.gun_sound_6 = arcade.load_sound("Sound/explosion (6).wav")
        self.gun_sound_7 = arcade.load_sound("Sound/explosion (7).wav")
        self.gun_sound_8 = arcade.load_sound("Sound/explosion (8).wav")
        self.no_butt = arcade.load_sound("Sound/No bullets.wav")
        self.sound1f = arcade.load_sound("Sound/Music/Found Sound 1.mp3")
        self.sound_fond = arcade.play_sound(self.sound1f, 0.5, 0, True, 1)
        self.button = Buttimage()
        self.v_gui1 = arcade.Sprite("Sprite/GUI/vixual gui.png", 1.6)
        self.v_gui1.center_y = 899
        self.v_gui1.center_x = 250
        self.center_button_x_run = 0
        self.rotate_player = True
        self.spawm_button = True
        self.effect_sound1 = arcade.load_sound("Sound/simple.wav")
        self.effect_sound2 = arcade.load_sound("Sound/fire.wav")
        self.effect_sound3 = arcade.load_sound("Sound/takeover.wav")
        self.effect_sound4 = arcade.load_sound("Sound/vampirism.wav")
        self.gun_x_plus = 0
        self.gun_x_add = True


    def on_draw(self):
        self.clear()
        arcade.set_background_color(arcade.color.DARK_JUNGLE_GREEN)
        self.hero.draw()
        self.visual.draw()
        self.walls.draw()
        self.emetys.draw()
        if self.spawm_button == True:
            if self.rotate_player == False:
                if self.center_button_x_run <= self.guns.range:
                    self.button.draw()
                else:
                    self.spawm_button = False

            elif self.rotate_player == True:
                if self.center_button_x_run >= -self.guns.range:
                    self.button.draw()
                else:
                    self.spawm_button = False
        self.guns.draw()
        self.v_gui1.draw()
        self.herds.draw()
        self.visual_button.draw()

        self.num.draw()
        self.num2.draw()
        self.num3.draw()

    def update(self, delta_time: float):
        if self.gun_x_add:
            self.gun_x_plus += 0.5
        else:
            self.gun_x_plus -= 0.5
        if self.gun_x_plus >= 5:
            self.gun_x_add = False
        elif self.gun_x_plus <= -5:
            self.gun_x_add = True
        self.guns.update()
        if self.guns.gun_visual_vid <= 4:
            if self.rotate_player:
                self.button.texture = self.button.image1[1]
            else:
                self.button.texture = self.button.image1[0]
        if self.guns.gun_visual_vid == 5:
            if self.rotate_player:
                self.button.texture = self.button.image2[1]
            else:
                self.button.texture = self.button.image2[0]
        if self.guns.gun_visual_vid == 6:
            if self.rotate_player:
                self.button.texture = self.button.image3[1]
            else:
                self.button.texture = self.button.image3[0]
        if self.guns.gun_visual_vid == 7 or self.guns.gun_visual_vid == 8:
            if self.rotate_player:
                self.button.texture = self.button.image4[1]
            else:
                self.button.texture = self.button.image4[0]
        if self.hero.center_x >= WIDTH and self.emety1.col_enemy == False:
            self.emety1.true_vid = True
            self.hero.center_x = 100
            self.emety1.col_enemy = False
        elif self.hero.center_x >= WIDTH:
            self.hero.center_x = WIDTH - 10
        self.hero.center_x += self.hero.speed_x
        self.hero.update()
        if self.emety1.healt <= 0:
            self.emety1.col_enemy = False
            if self.emety1.healt < 0:
                self.emety1.healt = 0
        if self.hero.center_x > self.emety1.center_x:
            self.emety1.flip = False
        elif self.hero.center_x < self.emety1.center_x:
            self.emety1.flip = True
        if self.emety1 != self.hero.center_x:
            self.emety1.run = False
        elif self.emety1 == self.hero.center_x:
            self.emety1.run = True
        if arcade.check_for_collision(self.button, self.emety1):
            self.button.center_y = self.guns.center_y + 100
            self.spawm_button = False
            if self.visual.s_sit == False:
                self.emety1.healt -= self.guns.gun_damage
            else:
                self.emety1.healt -= self.guns.gun_damage * 2
            self.guns.random_chance = random.randint(0, self.guns.gun_chance)
            if self.guns.random_chance == 0:
                if self.guns.type_effect == "simple":
                    self.emety1.healt -= 1
                    arcade.play_sound(self.effect_sound1, 0.5, 1, False)
                if self.guns.type_effect == "fire":
                    self.emety1.healt -= random.randint(5, 20)
                    arcade.play_sound(self.effect_sound2, 0.5, 1, False)
                if self.guns.type_effect == "takeover" and self.hero.healt > 1:
                    self.emety1.healt -= random.randint(100, 1000)
                    self.hero.healt -= 1
                    arcade.play_sound(self.effect_sound3, 0.5, 1, False)
                if self.guns.type_effect == "vampirism" and self.hero.healt < 9:
                    self.hero.healt += 1
                    arcade.play_sound(self.effect_sound4, 0.5, 1, False)

        if arcade.check_for_collision(self.hero, self.emety1) and self.hero.zreset == 100:
            if self.rotate_player == False:
                self.hero.center_x -= 200
            else:
                self.hero.center_x += 200
            self.hero.center_y += 100
            self.hero.healt -= 1
            self.hero.zreset = 0
            arcade.play_sound(self.hit_sound, 0.5, 1, False)

        self.visual.center_x = self.hero.center_x
        self.visual.center_y = self.hero.center_y
        self.guns.center_x = self.hero.center_x
        if self.visual.s_sit == False:
            self.guns.center_y = self.hero.center_y - 5 +self.gun_x_plus
        else:
            self.guns.center_y = self.hero.center_y - 40 +self.gun_x_plus
        if self.gun == True and self.guns.cartridges > 0:
            self.gun = False
            self.guns.cartridges -= 1
            self.spawm_button = True
            self.center_button_x_run = 0
            self.button.center_y = self.guns.center_y
            self.button.center_x = self.hero.center_x
        if self.rotate_player == True and self.spawm_button == True:
            if self.center_button_x_run >= -1000:
                self.center_button_x_run -= 80
                self.button.center_y -= 1
                self.button.center_x -= 80
            if self.rotate_player == False:
                self.spawm_button == False
        elif self.rotate_player == False and self.spawm_button == True:
            if self.center_button_x_run <= 1000:
                self.center_button_x_run += 80
                if self.visual.s_sit == False:
                    self.button.center_y -= 3
                else:
                    self.button.center_y -= 4
                self.button.center_x += 80
            if self.rotate_player == True:
                self.spawm_button == False
        if self.emety1.healt != 0:
            self.physics_engine1.update()
        self.physics_engine.update()
        if self.hero.bottom == self.wall.top or self.hero.bottom == self.wall1.top or self.hero.bottom == self.wall2.top:
            self.hero.on_jump = False
        if WIDTH//2 < self.hero.center_x:
            if self.visual.s_sit == False:
                if self.hero.speed_x != 0:
                    self.visual.texture = self.visual.textures_r[int(self.visual.t_index)]
                if self.hero.speed_x == 0:
                    self.visual.texture = self.visual.textures_r_stand[int(self.visual.t_index)]
            else:
                if self.hero.speed_x != 0:
                    self.visual.texture = self.visual.textures_rs[int(self.visual.t_index)]
                if self.hero.speed_x == 0:
                    self.visual.texture = self.visual.textures_r_stand_sit[int(self.visual.t_index)]
            self.guns.rotate_flip = 1
            self.rotate_player = True
        elif WIDTH//2 > self.hero.center_x:
            if self.visual.s_sit == False:
                if self.hero.speed_x != 0:
                    self.visual.texture = self.visual.textures_l[int(self.visual.t_index)]
                if self.hero.speed_x == 0:
                    self.visual.texture = self.visual.textures_l_stand[int(self.visual.t_index)]
            else:
                if self.hero.speed_x != 0:
                    self.visual.texture = self.visual.textures_ls[int(self.visual.t_index)]
                if self.hero.speed_x == 0:
                    self.visual.texture = self.visual.textures_l_stand_sit[int(self.visual.t_index)]
            self.guns.rotate_flip = 0
            self.rotate_player = False
        self.num.texture = self.num.textures[int(self.hero.healt)]
        self.num2.texture = self.num.textures[int(self.guns.cartridges // 10)]
        self.num3.texture = self.num.textures[int(self.guns.cartridges % 10)]
        if self.hero.speed_x != 0:
            self.visual.anim = True
        else:
            self.visual.anim = False
        self.visual.update()
        self.emetys.update()
        if self.hero.healt <= 1:
            self.herds.texture = self.herds.healt[1]
        elif self.hero.healt > 1:
            self.herds.texture = self.herds.healt[0]
        if self.guns.cartridges == 0:
            self.visual_button.texture = self.visual_button.butt[1]
        elif self.hero.healt > 0:
            self.visual_button.texture = self.visual_button.butt[0]

    def on_key_press(self, symbol: int, modifiers: int):
        if symbol == arcade.key.D:
            self.hero.speed_x = self.hero.speed_player
        elif symbol == arcade.key.A:
            self.hero.speed_x = -self.hero.speed_player
        if symbol == arcade.key.W and not self.hero.on_jump and self.visual.s_sit == False:
            self.hero.on_jump = True
            arcade.play_sound(self.junp_sound, 0.3, 1, False)
        if symbol == arcade.key.R:
            if self.guns.gun_visual_vid == 1:
                self.guns.cartridges = 60
            if self.guns.gun_visual_vid == 2:
                self.guns.cartridges = 5
            if self.guns.gun_visual_vid == 3:
                self.guns.cartridges = 80
            if self.guns.gun_visual_vid == 4:
                self.guns.cartridges = 10
            if self.guns.gun_visual_vid == 5:
                self.guns.cartridges = 30
            if self.guns.gun_visual_vid == 6:
                self.guns.cartridges = 2
            if self.guns.gun_visual_vid == 7:
                self.guns.cartridges = 66
            if self.guns.gun_visual_vid == 8:
                self.guns.cartridges = 45
        if symbol == arcade.key.S and self.hero.on_jump == False:
            self.visual.s_sit = True
        if symbol == arcade.key.F1:
            self.guns.gun_visual_vid += 1
            if self.guns.gun_visual_vid > 8:
                self.guns.gun_visual_vid = 1
            self.guns.add_select_guns = True

        if symbol == arcade.key.F and self.guns.add_fire == self.guns.tick_fire:
            self.guns.add_fire = 0
            if self.guns.cartridges > 0:
                self.gun = True
            if self.guns.cartridges > 0:
                if self.guns.gun_visual_vid == 1:
                    self.player1 = arcade.play_sound(self.gun_sound_1, 0.3, 0, False, 2)
                if self.guns.gun_visual_vid == 2:
                    self.player2 = arcade.play_sound(self.gun_sound_2, 0.3, 0, False, 2)
                if self.guns.gun_visual_vid == 3:
                    self.player3 = arcade.play_sound(self.gun_sound_3, 0.3, 0, False, 2)
                if self.guns.gun_visual_vid == 4:
                    self.player4 = arcade.play_sound(self.gun_sound_4, 0.3, 0, False, 2)
                if self.guns.gun_visual_vid == 5:
                    self.player5 = arcade.play_sound(self.gun_sound_5, 0.3, 0, False, 2)
                if self.guns.gun_visual_vid == 6:
                    self.player6 = arcade.play_sound(self.gun_sound_6, 0.3, 0, False, 2)
                if self.guns.gun_visual_vid == 7:
                    self.player7 = arcade.play_sound(self.gun_sound_7, 0.3, 0, False, 2)
                if self.guns.gun_visual_vid == 8:
                    self.player8 = arcade.play_sound(self.gun_sound_8, 0.3, 0, False, 2)
            elif self.guns.cartridges <= 0:
                self.player = arcade.play_sound(self.no_butt, 1, 0, False, 1)

    def on_key_release(self, symbol: int, modifiers: int):
        if symbol == arcade.key.D and self.hero.speed_x > 0:
            self.hero.speed_x = 0
        elif symbol == arcade.key.A and self.hero.speed_x < 0:
            self.hero.speed_x = 0
        if symbol == arcade.key.S:
            self.visual.s_sit = False


# Класс кнопки для меню
class Button_newgame(arcade.Sprite):
    def __init__(self, x, y, sp1, sp2, s):
        super().__init__()
        self.textures_button = []
        self.textures_button.append(arcade.load_texture(sp1))
        self.textures_button.append(arcade.load_texture(sp2))
        self.texture = self.textures_button[0]
        self.center_x = x
        self.center_y = y
        self.scale = s

class Setting(arcade.View):
    def __init__(self):
        super().__init__()
        self.volume = 50

    def on_draw(self):
        self.clear()
        arcade.set_background_color(arcade.color.BLACK)

    def update(self, delta_time: float):
        pass


# Код окна меню
class Menu(arcade.View):
    def __init__(self):
        super().__init__()
        self.logo = arcade.Sprite("Sprite/GUI/EverDeadBack.png", 1.3, center_x=HEIGHT - 200, center_y=WIDTH - 300)
        self.nummer_button = 1
        self.button_new_game = Button_newgame(WIDTH // 2, HEIGHT // 2, "Sprite/GUI/button_newgame.png",
                                              "Sprite/GUI/button_newgame_add.png", 0.9)
        self.button_exit_game = Button_newgame(WIDTH // 2, HEIGHT // 2 - 140, "Sprite/GUI/button_exit_off.png",
                                               "Sprite/GUI/button_exit.png", 0.9)
        self.button_setting_game = Button_newgame(WIDTH // 2, HEIGHT // 2 - 20, "Sprite/GUI/button_settings.png",
                                                  "Sprite/GUI/button_settings_add.png", 0.9)
        self.sound3f = arcade.load_sound("Sound/Music/Found Sound 3.mp3")
        self.sound_fond = arcade.play_sound(self.sound3f, 1, 0, True, 1)
        self.selectv = arcade.load_sound("Sound/blipSelect (2).wav")
        self.logo_testersgame_alpha = arcade.Sprite("Alpha_logo_TESTER.png", 0.52, center_x=self.logo.center_x - 360,
                                                    center_y=self.logo.center_y - 195)
        self.button_add = False

    def on_draw(self):
        self.clear()
        arcade.set_background_color(arcade.color.BLACK)
        self.logo.draw()
        self.button_new_game.draw()
        self.button_exit_game.draw()
        self.button_setting_game.draw()
        self.logo_testersgame_alpha.draw()

    def update(self, delta_time: float):
        if self.sound_fond.volume >= 0.01 and self.button_add == True:
            self.sound_fond.volume -= 0.02
        if self.nummer_button == 1 and self.sound_fond.volume <= 0.01:
            game_view = Game()
            game.show_view(game_view)
        if self.nummer_button == 2 and self.sound_fond.volume <= 0.01:
            settings_view = Setting()
            game.show_view(settings_view)
        if self.nummer_button == 3 and self.sound_fond.volume <= 0.01:
            arcade.close_window()
        if self.nummer_button > 3:
            self.nummer_button = 1
        if self.nummer_button < 1:
            self.nummer_button = 3
        if self.nummer_button == 1:
            self.button_new_game.texture = self.button_new_game.textures_button[1]
            self.button_new_game.center_x = WIDTH // 2
        else:
            self.button_new_game.texture = self.button_new_game.textures_button[0]
            self.button_new_game.center_x = WIDTH // 2 + 10
        if self.nummer_button == 3:
            self.button_exit_game.texture = self.button_exit_game.textures_button[1]
            self.button_exit_game.center_x = WIDTH // 2 - 2
        else:
            self.button_exit_game.texture = self.button_exit_game.textures_button[0]
            self.button_exit_game.center_x = WIDTH // 2 + 8
        if self.nummer_button == 2:
            self.button_setting_game.texture = self.button_setting_game.textures_button[1]
            self.button_setting_game.center_x = WIDTH // 2 + 25
        else:
            self.button_setting_game.texture = self.button_setting_game.textures_button[0]
            self.button_setting_game.center_x = WIDTH // 2 + 35

    def on_key_press(self, symbol: int, modifiers: int):
        if symbol == arcade.key.D and self.button_add == False:
            self.button_add = True
        if symbol == arcade.key.S and self.button_add == False:
            self.nummer_button += 1
            arcade.play_sound(self.selectv, 0.5, 0, False, 1)
        if symbol == arcade.key.W and self.button_add == False:
            self.nummer_button -= 1
            arcade.play_sound(self.selectv, 0.5, 0, False, 1)


game = arcade.Window(WIDTH, HEIGHT, TITLE, False)
start_view = Menu()
game.show_view(start_view)
arcade.run()
arcade.close_window()
